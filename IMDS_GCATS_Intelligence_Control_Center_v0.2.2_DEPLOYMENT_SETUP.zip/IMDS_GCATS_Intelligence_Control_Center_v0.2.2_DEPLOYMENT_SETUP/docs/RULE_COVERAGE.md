# Rule coverage and activation status

| Error Type / family | Current implementation | Activation status |
|---|---|---|
| 1 Region | Manual verification task and source-trace note | Source-listed; manual |
| 2 Supplier Code | Supplier code verification workflow | Source-listed; manual |
| 3 Part number | SMS/source part number verification workflow | Source-listed; manual |
| 4 preliminary IMDS | Preliminary/final check; supplier pre-check readiness | Source-listed; manual confirmation |
| 5 Material module nor Semi-component | Component-only submission instruction | Source-listed; manual confirmation |
| 6 SMS Mass | Supplier confirmation branches and source comments | Draft for process-owner approval |
| 7 Mass tolerance range | Decimal comparison against extracted TSZ2900 range table plus drawing/SMS verification tasks | Reference-only / draft; controlled TSZ2900G Rev.9 and applicability verification required |
| 8 Mass deviation | Holds for approved percentage basis | Manual review; denominator/rounding unresolved |
| 9 Not specified substance | 10% and multi-material branches | Draft for process-owner approval; denominator/material basis must be verified |
| 10 ELV (Pb) | Application ID, destination and policy evidence guardrails; Application 71 manual branch | Manual review; exact policy row and destination evidence required |
| 11 ELV (Cd) | Human review and source flow reference | Manual review required |
| 12 ELV (Hg) | Human review and source flow reference | Manual review required |
| 13 ELV (Cr6+) | Human review and source flow reference | Manual review required |
| 14 Prohibited substance | CAS → GADSL → TSZ → family flow workflow | HOLD / manual; no universal threshold |
| 15–18 specific prohibited substances | Substance-family route and evidence task | Manual review required |
| 19 | Numeric Error Type always HOLD | Owner reconciliation required due source conflict |
| 20–23 | Manual verification tasks | Source-listed; manual |
| MCCP draft workbook flow | Data preserved as draft reference | Not activated |
| Battery (Pb), Battery (Cd), Tokusetsu Part number, SCCP historical labels | Preserved independently from official numeric catalogue | Historical-only; owner mapping required |

## Historical suggestion behavior

The procedure suggestion service groups imported history only within the exact historical Error Type label. It queries same part, same supplier and same CAS independently and ranks matching procedure strings. Suggested OK/NG comments are historical examples, not approved templates for the new record. No result is auto-copied into the active Judge/KM Judge fields.

## Final decision

The judgement service creates a recommendation and trace only. `finalDecision` stays `PENDING`. The final approval RPC requires a reviewer/admin/rule approver and an approved/active rule version, and checks recommendation polarity. Current draft/manual branches remain blocked from finalization until rule governance and source-owner validation are completed.
